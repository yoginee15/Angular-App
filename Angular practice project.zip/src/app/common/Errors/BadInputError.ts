import { AppError } from './AppError';


export class BadInputError extends AppError{

}