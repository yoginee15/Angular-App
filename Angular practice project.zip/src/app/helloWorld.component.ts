import { Component } from '@angular/core';

@Component({
    selector:"helloWorld",
    template:"<h1>Hello World</h1>"
})

export class HelloWorldComponent{

}